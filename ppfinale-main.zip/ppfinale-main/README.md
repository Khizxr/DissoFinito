# Security Dashboard for Web Applications

AI-assisted vulnerability scanner.

## Quick Start (Codespaces)

